import 'package:flutter/material.dart';

class SearchPage extends StatelessWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141118),
      appBar: AppBar(
        backgroundColor: const Color(0xFF141118),
        elevation: 0,
        title: const Text(
          'Search',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            letterSpacing: -0.015,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.edit, color: Colors.white),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF302938),
                prefixIcon: const Icon(Icons.search, color: Color(0xFFab9db8)),
                hintText: 'Search',
                hintStyle: const TextStyle(color: Color(0xFFab9db8)),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
              style: const TextStyle(color: Colors.white),
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Text(
              'Recent searches',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                letterSpacing: -0.015,
              ),
            ),
          ),
          const Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _RecentSearchItem(
                    name: 'Eva',
                    imageUrl:
                        'https://cdn.usegalileo.ai/sdxl10/4fd3ddef-c0c9-40b6-9ca1-729efa3f42aa.png',
                  ),
                  _RecentSearchItem(
                    name: 'Mason',
                    imageUrl:
                        'https://cdn.usegalileo.ai/sdxl10/436c4b17-4411-4049-8507-51d4df0352cd.png',
                  ),
                  _RecentSearchItem(
                    name: 'Liam',
                    imageUrl:
                        'https://cdn.usegalileo.ai/sdxl10/0321b52c-d0d1-4667-9bf8-cc990eebf69f.png',
                  ),
                  _RecentSearchItem(
                    name: 'Olivia',
                    imageUrl:
                        'https://cdn.usegalileo.ai/sdxl10/409884b7-d537-43d6-9b6b-179c0ed59727.png',
                  ),
                  _RecentSearchItem(
                    name: 'William',
                    imageUrl:
                        'https://cdn.usegalileo.ai/sdxl10/ef785a92-0f27-4f1d-a36f-262f6b06cb01.png',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RecentSearchItem extends StatelessWidget {
  final String name;
  final String imageUrl;

  const _RecentSearchItem({
    Key? key,
    required this.name,
    required this.imageUrl,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        children: [
          CircleAvatar(
            backgroundImage: NetworkImage(imageUrl),
            radius: 20,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              name,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.normal,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
