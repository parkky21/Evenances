// home.dart
import 'package:flutter/material.dart';
import 'package:flutter_application_1/screens/chat_screen.dart';
import 'package:flutter_application_1/screens/search.dart';


class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF141118),
        title: const Text(
          'Chats',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            letterSpacing: -0.015,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          const SearchBar(),
          Expanded(
            child: ListView(
              children: const [
                ChatItem(
                  name: 'Maggie',
                  message: "I'll be there in 10 minutes",
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/e88c82de-2c73-4f5d-9508-71577a36eeed.png',
                ),
                ChatItem(
                  name: 'Celia',
                  message: 'Happy birthday! How are you celebrating?',
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/40f70546-ecd7-4361-be87-04d23971368e.png',
                ),
                ChatItem(
                  name: 'Liam',
                  message: "No problem, I'll get it done by tomorrow",
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/aa394c35-699f-4ded-93d2-23dacdc8fed6.png',
                ),
                ChatItem(
                  name: 'Elijah',
                  message: "It's been a while since we last met up. Let's catch up soon.",
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/0e0125d5-054f-4393-8e42-3d04d85587e0.png',
                ),
                ChatItem(
                  name: 'Benjamin',
                  message: "Thanks for the reminder. I'll make sure to get it done today.",
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/293257b6-b3eb-4b1f-a7ba-2194e36d99ef.png',
                ),
                ChatItem(
                  name: 'Benjamin',
                  message: "Thanks for the reminder. I'll make sure to get it done today.",
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/293257b6-b3eb-4b1f-a7ba-2194e36d99ef.png',
                ),
                ChatItem(
                  name: 'Benjamin',
                  message: "Thanks for the reminder. I'll make sure to get it done today.",
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/293257b6-b3eb-4b1f-a7ba-2194e36d99ef.png',
                ),ChatItem(
                  name: 'Benjamin',
                  message: "Thanks for the reminder. I'll make sure to get it done today.",
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/293257b6-b3eb-4b1f-a7ba-2194e36d99ef.png',
                ),ChatItem(
                  name: 'Benjamin',
                  message: "Thanks for the reminder. I'll make sure to get it done today.",
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/293257b6-b3eb-4b1f-a7ba-2194e36d99ef.png',
                ),ChatItem(
                  name: 'Benjamin',
                  message: "Thanks for the reminder. I'll make sure to get it done today.",
                  imageUrl: 'https://cdn.usegalileo.ai/sdxl10/293257b6-b3eb-4b1f-a7ba-2194e36d99ef.png',
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: const BottomNavBar(),
    );
  }
}

class SearchBar extends StatelessWidget {
  const SearchBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: TextField(
        decoration: InputDecoration(
          filled: true,
          fillColor: const Color(0xFF302938),
          prefixIcon: const Icon(Icons.search, color: Color(0xFFab9db8)),
          hintText: 'Search',
          hintStyle: const TextStyle(color: Color(0xFFab9db8)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}

class ChatItem extends StatelessWidget {
  final String name;
  final String message;
  final String imageUrl;

  const ChatItem({
    Key? key,
    required this.name,
    required this.message,
    required this.imageUrl,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ChatScreen(
              name: name,
              imageUrl: imageUrl,
            ),
          ),
        );
      },
      child: ListTile(
        leading: CircleAvatar(
          backgroundImage: NetworkImage(imageUrl),
          radius: 28,
        ),
        title: Text(
          name,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          message,
          style: const TextStyle(
            color: Color(0xFFab9db8),
          ),
        ),
      ),
    );
  }
}


class BottomNavBar extends StatelessWidget {
  const BottomNavBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      backgroundColor: const Color(0xFF211c26),
      selectedItemColor: Colors.white,
      unselectedItemColor: const Color(0xFFab9db8),
      onTap: (index) {
        if (index == 1) { // Navigate to SearchPage when "Search" tab is tapped
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const SearchPage()),
          );
        }
        // Handle other tabs here if needed
      },
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.chat),
          label: 'Chats',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.search),
          label: 'Search',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: 'People',
        ),
      ],
    );
  }
}
