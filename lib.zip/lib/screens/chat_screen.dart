import 'package:flutter/material.dart';

class ChatScreen extends StatelessWidget {
  final String name;
  final String imageUrl;

  const ChatScreen({
    Key? key,
    required this.name,
    required this.imageUrl,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1a1122),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1a1122),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: Text(
          name,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(8.0),
              children: [
                // Add chat bubbles here or fetch messages dynamically
              ],
            ),
          ),
          _buildMessageInput(),
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.all(8.0),
      color: const Color(0xFF1a1122),
      child: Row(
        children: [
          CircleAvatar(
            backgroundImage: NetworkImage(imageUrl),
            radius: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: "Message $name...",
                hintStyle: const TextStyle(color: Color(0xFFad93c8)),
                filled: true,
                fillColor: const Color(0xFF362447),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.add, color: Color(0xFFad93c8)),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.mic, color: Color(0xFFad93c8)),
            onPressed: () {},
          ),
        ],
      ),
    );
  }
}
